All credits go to hypr9xa for making the base of this, this is just an edited version to make it much much better.

Note:
If ur using ESX 1.1 make sure to upload esx1.1.sql and if ur using ESX 1.2 upload esx1.2.sql and if ur ExtendedMode upload exm.sql.