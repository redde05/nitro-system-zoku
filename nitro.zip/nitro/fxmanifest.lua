fx_version 'cerulean'
game 'gta5'


description 'hypr9nitro'

server_scripts {
	'server/main.lua'
}

client_scripts {
	'client/main.lua'
}
